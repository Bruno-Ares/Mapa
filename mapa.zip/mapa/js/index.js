const inputCep = document.querySelector("#inputCEP")
const local = document.querySelector("#local")
const latitude = document.querySelector("#lat")
const longitude = document.querySelector("#long")

const endereco = document.querySelector("#inputEndereco")

var markers = []; // Lista pros marcadores

//chave para a API, lembre de mudar após a expiração no site HERE
const KEY_API = 'bpCvUJlSkTzcUdpIxkdkXagfZ_o7Ryuk2z2C6c_yA4w';

//Carrega todos os dados  do API na plataforma HERE
const platform = new H.service.Platform({
  'apikey': KEY_API
});

// Obtendo os mapas da plataforma
var defaultLayers = platform.createDefaultLayers();

// Instancia e exibe o map object:
var map = new H.Map(
  document.getElementById('mapContainer'),
  defaultLayers.vector.normal.map,
  {
      zoom: 10,
      center: { lat: -10.9472, lng: -37.0731 }
  }
);

// Habilita o sistema de eventos do mapa como clicar e arrastar
var mapEvents = new H.mapevents.MapEvents(map);
var behavior = new H.mapevents.Behavior(mapEvents);
var ui = H.ui.UI.createDefault(map, defaultLayers);

const encontrarLocalizacao = (valor) =>{
  fetch(`https://geocode.search.hereapi.com/v1/geocode?q=${valor}&apikey=${KEY_API}`)
      .then(response => response.json())
      .then(data => {
          console.log(data)
          if (data.items.length > 0) {
              local.innerHTML = data.items[0].title
              var location = data.items[0].position;
              map.setCenter(location);
              map.setZoom(14);
              addMarker(location);
              document.getElementById("posicao").classList.remove("invisible")
              document.getElementById("endereco").classList.remove("invisible")
              latitude.innerHTML = "Latitude: " + data.items[0].position.lat
              longitude.innerHTML = "Longitude: " +  data.items[0].position.lng

          } else {
              alert('Localização não encontrada!');
          }
      });

}
inputCep.addEventListener("input", function(e) {
  var value = e.target.value
  var padraoCEP = value.replace(/\D/g, '') //Remove qualquer informação que não seja numero
                       .replace(/(\d{5})(\d)/, '$1-$2')

  e.target.value = padraoCEP;
})


inputCep.addEventListener("keydown", (event) =>
{
  if (event.key === 'Enter')//Ao pressionar Enter, ele irá buscar pela localização do CEP
  {
   let cep = inputCep.value
   encontrarLocalizacao(cep)
    inputCep.value = "";
  } 
})

endereco.addEventListener("keydown", (event) => {

  if(event.key === 'Enter'){
      let logradouro = endereco.value
      encontrarLocalizacao(logradouro);
      endereco.value = "";
  }
});

// Funçao para add marcador no mapa
function addMarker(location) {
  var marker = new H.map.Marker(location);
  markers.push(marker); // Add o marcador na lista
  map.addObject(marker);
  map.setCenter(location); // Centraliza no marcador

  // Add click listener para remover o marcador
  marker.addEventListener('tap', function () {
      map.removeObject(marker); // Remove o marcador do mapa
      markers = markers.filter(m => m !== marker); // Remove o marcador da lista
  });
}